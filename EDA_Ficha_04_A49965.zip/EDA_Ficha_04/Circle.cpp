#include"Circle.h"

Circle::Circle(Point c, int r) {
	center = c;
	radius = r;
}


void Circle::Draw(HWND wndId, long color)
{
	if (wndId != NULL)
	{
		HDC DrawHDC = GetDC(wndId);
		// penstyle, width, color
		HPEN hNPen = CreatePen(PS_SOLID, 10, color);
		HPEN hOPen = (HPEN)SelectObject(DrawHDC, hNPen);
		HBRUSH hOldBrush = CreateSolidBrush(color);;
		Ellipse(DrawHDC, center.GetX() - radius, center.GetY() + radius,
			center.GetX() + radius, center.GetY() - radius);
		DeleteObject(SelectObject(DrawHDC, hOPen));
		DeleteObject(SelectObject(DrawHDC, hOldBrush));
		ReleaseDC(wndId, DrawHDC);
	}
}


bool Circle::Contains(Point p) { //Um ponto est� dentro de um circle quando a distancia ao
	if (center.GetDistance(p) < radius) return true; //Compara com a this
	else return false;
};